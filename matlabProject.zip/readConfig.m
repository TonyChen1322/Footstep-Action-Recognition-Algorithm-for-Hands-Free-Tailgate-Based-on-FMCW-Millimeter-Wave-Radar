function [cmds,paras] = readConfig(path)
    % ��ȡJson
    rawJsonText = fileread(path + "config.json");
    config = jsondecode(rawJsonText); % ����json�ı�
    % ��ȡ����
    tmp = config.Commands;
    cmds = strings(length(tmp),1);
    for i = 1:length(tmp)
        cmds(i) = tmp{i};
    end
    paras = struct();
    
    paras.FFTpoints = config.Configuration.FFTpoints;
    paras.Param_S = config.Configuration.Param_S;
    paras.Param_Tc = config.Configuration.Param_Tc;
    paras.Param_fs = config.Configuration.Param_fs;
    paras.Param_samplenum = config.Configuration.Param_samplenum;
    paras.Param_startFre = config.Configuration.Param_startFre;
    paras.FrameTime = config.Configuration.FrameTime;
%     clear config rawJsonText tmp i; 
end