% isRevolve �Ƿ������ƽ��
function outData = structMean(impData, isRevolve)
    outData = struct();
    outData.gnd = impData.gnd;
    if isRevolve
        outData.x = nanMean(impData.x')';
        outData.y = nanMean(impData.y')';
        outData.z = nanMean(impData.z')';
        outData.r = nanMean(impData.r')';
        outData.v = nanMean(impData.v')';   
    else
        outData.x = nanMean(impData.x);
        outData.y = nanMean(impData.y);
        outData.z = nanMean(impData.z);
        outData.r = nanMean(impData.r);
        outData.v = nanMean(impData.v);
    end
end