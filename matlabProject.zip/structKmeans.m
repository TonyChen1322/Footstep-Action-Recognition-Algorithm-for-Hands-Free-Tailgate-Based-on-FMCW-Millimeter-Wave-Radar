function outData = structKmeans(impData, K)
    if isempty(impData)
        outData = [];
        return;
    end
    [~,C] = kmeans([impData.x, impData.y, impData.z], K);
    
    outData = struct();
    outData.x = C(:,1); 
    outData.y = C(:,2); 
    outData.z = C(:,3);     
    outData.r = [];     
    outData.v = [];     
    outData.gnd = [];
end