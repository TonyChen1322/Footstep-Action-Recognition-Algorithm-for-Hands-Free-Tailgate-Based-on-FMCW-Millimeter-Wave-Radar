% linesPara ֱ�߲���
% impPoint ����Ĵ��жϵ㣬x y z
% points �ϲ��Ժ���������
% witchCluster �Ƿ���У�0δ���У�1�����м�أ�2������ߴأ�3�����ұߴ�
% ranges ����Ӧ�صľ���
% rate ���еı���
function [points, witchCluster, ranges, rate] = structJudgment(linesPara, impPoint)
    cnt = 0;
    len = size(impPoint,1);
    witchCluster = zeros(len, 1);
    ranges = NaN(len, 1);
    points = [];
    
    for i = 1 : len
        points = [points; [impPoint(i).x, impPoint(i).y, impPoint(i).z]];
        
        if ((points(i,:) >= linesPara.front.budryMin) & (points(i,:) <= linesPara.front.budryMax))
            tmpRange = pointToLine3(points(i,:), linesPara.front.s, linesPara.front.A);
            if (tmpRange <= linesPara.front.rangeMax)
                % disp('front');
                witchCluster(i) = 1;         % �����м��
                ranges(i) = tmpRange;
                cnt = cnt + 1;
                continue;
            end
        end
            
        if ((points(i,:) >= linesPara.left.budryMin) & (points(i,:) <= linesPara.left.budryMax))
            tmpRange = pointToLine3(points(i,:), linesPara.left.s, linesPara.left.A);
            if (tmpRange <= linesPara.left.rangeMax)
                % disp('left');
                witchCluster(i) = 2;         % ������ߴ�
                ranges(i) = tmpRange;
                cnt = cnt + 1;
                continue;
            end
        end
            
        if ((points(i,:) >= linesPara.right.budryMin) & (points(i,:) <= linesPara.right.budryMax))
            tmpRange = pointToLine3(points(i,:), linesPara.right.s, linesPara.right.A);
            if (tmpRange <= linesPara.right.rangeMax)
                % disp('right');
                witchCluster(i) = 3;         % �����ұߴ�
                ranges(i) = tmpRange;
                cnt = cnt + 1;
                continue;
            end           
        end
        
    end
    rate = cnt / len;
end