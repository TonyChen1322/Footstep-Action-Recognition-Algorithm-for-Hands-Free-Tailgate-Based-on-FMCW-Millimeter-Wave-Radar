% ��devide�ṹ�����ȡƬ��
function outData = structIntercept(impData, idxStart, idxEnd)
    outData = struct();
    outData.x = impData.x(idxStart:idxEnd, :);
    outData.y = impData.y(idxStart:idxEnd, :);
    outData.z = impData.z(idxStart:idxEnd, :);
    outData.r = impData.r(idxStart:idxEnd, :);
    outData.v = impData.v(idxStart:idxEnd, :);
    outData.gnd = impData.gnd;
end