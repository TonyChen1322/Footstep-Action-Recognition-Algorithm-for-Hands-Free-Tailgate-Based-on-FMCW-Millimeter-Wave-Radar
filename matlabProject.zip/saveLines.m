function saveLines(dataToSave)
    lines = struct();
    
    lines.front.A = dataToSave.front.A;
    lines.front.s = dataToSave.front.s;
    lines.front.xMin = dataToSave.front.xMin;
    lines.front.xMax = dataToSave.front.xMax;
    lines.front.plotMin = dataToSave.front.budry(1,:);
    lines.front.plotMax = dataToSave.front.budry(end,:);
    lines.front.budryMin = dataToSave.front.budryMin;
    lines.front.budryMax = dataToSave.front.budryMax;
    lines.front.rangeMax = dataToSave.front.rangeMax;
    
    lines.left.A = dataToSave.left.A;
    lines.left.s = dataToSave.left.s;
    lines.left.xMin = dataToSave.left.xMin;
    lines.left.xMax = dataToSave.left.xMax;
    lines.left.plotMin = dataToSave.left.budry(1,:);
    lines.left.plotMax = dataToSave.left.budry(end,:);
    lines.left.budryMin = dataToSave.left.budryMin;
    lines.left.budryMax = dataToSave.left.budryMax;
    lines.left.rangeMax = dataToSave.left.rangeMax;

    lines.right.A = dataToSave.right.A;
    lines.right.s = dataToSave.right.s;
    lines.right.xMin = dataToSave.right.xMin;
    lines.right.xMax = dataToSave.right.xMax;
    lines.right.plotMin = dataToSave.right.budry(1,:);
    lines.right.plotMax = dataToSave.right.budry(end,:);
    lines.right.budryMin = dataToSave.right.budryMin;
    lines.right.budryMax = dataToSave.right.budryMax;
    lines.right.rangeMax = dataToSave.right.rangeMax;

    jsonStr = jsonencode(lines);
    filename = 'lines.json';
    fid = fopen(filename, 'w');
    if fid == -1
        error('�޷����ļ�: %s', filename);
    end
    fprintf(fid, '%s', jsonStr);
    fclose(fid);
end