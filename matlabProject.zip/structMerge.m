function outData = structMerge(impData, isCleanNan)
    outData = struct();
    outData.gnd = [];
    outData.x = []; 
    outData.y = []; 
    outData.z = []; 
    outData.r = []; 
    outData.v = []; 
    for i = 1 : length(impData)
        outData.gnd = [outData.gnd; impData(i).gnd];
        outData.x = [outData.x; impData(i).x(:)];
        outData.y = [outData.y; impData(i).y(:)];
        outData.z = [outData.z; impData(i).z(:)];
        outData.r = [outData.r; impData(i).r(:)];
        outData.v = [outData.v; impData(i).v(:)];      
    end
    if isCleanNan
        outData.x(isnan(outData.x)) = [];
        outData.y(isnan(outData.y)) = [];
        outData.z(isnan(outData.z)) = [];
        outData.r(isnan(outData.r)) = [];
        outData.v(isnan(outData.v)) = [];  
    end
end