% �ҵ�ֱ�ߵı߽磬���ȸ����ṩ��ɢ���ҳ���ֵ�㣬�ٽ���Щ��ͶӰ��ֱ���ϣ��õ������߽�㣬�ٸ���y������ѡ�������߽��
% linesPara ֱ�߲���
% budry ���ݵ�
function [budry, budryMin, budryMax] = findLineRange(linesPara)
%     rem = NaN(6,4);      % ��ĳ�㵽A�ľ��룬�Լ��õ��x y z����
    rem = NaN(6,3);      % ��ĳ�㵽A�ľ��룬�Լ��õ��x y z����
    
%     xMin = floor(min(linesPara.points(:,1))*100)/100;
    xMin = min(linesPara.points(:,1));
    t = (xMin - linesPara.A(1)) / linesPara.s(1);
    y = linesPara.A(2) + linesPara.s(2) * t;
    z = linesPara.A(3) + linesPara.s(3) * t;
%     r = (xMin - linesPara.A(1))^2 + (y - linesPara.A(2))^2 + (z - linesPara.A(3))^2;
    rem(1,:) = [xMin, y ,z];
    
%     yMin = floor(min(linesPara.points(:,2))*100)/100;
    yMin = min(linesPara.points(:,2));
    t = (yMin - linesPara.A(2)) / linesPara.s(2);
    x = linesPara.A(1) + linesPara.s(1) * t;
    z = linesPara.A(3) + linesPara.s(3) * t;
%     r = (x - linesPara.A(1))^2 + (yMin - linesPara.A(2))^2 + (z - linesPara.A(3))^2;
    rem(2,:) = [x, yMin ,z];
    
%     zMin = floor(min(linesPara.points(:,3))*100)/100;
    zMin = min(linesPara.points(:,3));
    t = (zMin - linesPara.A(3)) / linesPara.s(3);
    x = linesPara.A(1) + linesPara.s(1) * t;
    y = linesPara.A(2) + linesPara.s(2) * t;
%     r = (x - linesPara.A(1))^2 + (y - linesPara.A(2))^2 + (zMin - linesPara.A(3))^2;
    rem(3,:) = [x, y ,zMin];
    
%     xMax = ceil(max(linesPara.points(:,1))*100)/100;
    xMax = max(linesPara.points(:,1));
    t = (xMax - linesPara.A(1)) / linesPara.s(1);
    y = linesPara.A(2) + linesPara.s(2) * t;
    z = linesPara.A(3) + linesPara.s(3) * t;
%     r = (xMax - linesPara.A(1))^2 + (y - linesPara.A(2))^2 + (z - linesPara.A(3))^2;
    rem(4,:) = [xMax, y ,z];    
    
%     yMax = ceil(max(linesPara.points(:,2))*100)/100;    
    yMax = max(linesPara.points(:,2));    
    t = (yMax - linesPara.A(2)) / linesPara.s(2);
    x = linesPara.A(1) + linesPara.s(1) * t;
    z = linesPara.A(3) + linesPara.s(3) * t;
%     r = (x - linesPara.A(1))^2 + (yMax - linesPara.A(2))^2 + (z - linesPara.A(3))^2;
    rem(5,:) = [x, yMax ,z];       

%     zMax = ceil(max(linesPara.points(:,3))*100)/100;
    zMax = max(linesPara.points(:,3));
    t = (zMax - linesPara.A(3)) / linesPara.s(3);
    x = linesPara.A(1) + linesPara.s(1) * t;
    y = linesPara.A(2) + linesPara.s(2) * t;
%     r = (x - linesPara.A(1))^2 + (y - linesPara.A(2))^2 + (zMax - linesPara.A(3))^2;
    rem(6,:) = [x, y ,zMax];  
    
    % ��Ϊy����һ�������ģ�������y�Ĵ�С���ж�Զ��
    budry = [rem(rem(:,2) == max(rem(:,2)), :); rem(rem(:,2) == min(rem(:,2)), :)];
    budryMax = [max(budry(:,1)), max(budry(:,2)), max(budry(:,3))];
    budryMin = [min(budry(:,1)), min(budry(:,2)), min(budry(:,3))];
end


