clear; clc; close all;
%% ��ȡʵ������
dir = "E:/2.GraduationItems/04_Trunk/1_mmWaveRader/3_Projects/0_outOfBox_SourceData/20250112_AOP_4R3T_static/";
% idxRange = [1, 10000];
idxRange_bingo = [1, 10000];
idxRange_miss = [1, 5000];
figNum = 0;
windowLen = 1;      % ���ڳ��ȣ�֡����
winMoveStep = 1;    % ���ڣ�ÿ�λ����ĳ��ȣ�֡������ ע��windowLen >= winMoveStep
largerEpsilon = 0.2;      % DBSCAN ����뾶
epsilon = 0.07;    % DBSCAN ����뾶
minPts = 4;         % DBSCAN ��������С����
[~,paras] = readConfig(dir);
paras.Param_S = paras.Param_S * 1e6 / 1e-6;           % б�ʣ���λ Hz/s
paras.Param_Tc = paras.Param_Tc * 1e-6;               % Chirp�����ڣ���λ s
paras.Param_fs = paras.Param_fs * 1e6;                % ����Ƶ�ʣ���λ sps
paras.Param_startFre = paras.Param_startFre * 1e9;    % ��ʼƵ�ʣ���λ Hz
paras.Param_c = 3e8;                                  % ���٣���λ m/s
% fAxis = (0:(80-1)) * paras.Param_fs / 512;            %ֻҪ80����
% rangeAxis = paras.Param_c * fAxis / 2 / paras.Param_S;
% rangeAxis = 0:(80-1);


%% վ��ǰ��
standFront = struct();
standFront.bingo1 = readData(dir + "1_standFront/1_1_bingo/", true, idxRange_bingo, false);      % ���
standFront.bingo2 = readData(dir + "1_standFront/1_2_bingo/", true, idxRange_bingo, false);      % �ҽ�
standFront.miss1 = readData(dir + "1_standFront/2_1_miss/", true, idxRange_miss, false);         % ������
standFront.miss2 = readData(dir + "1_standFront/2_2_miss/", true, idxRange_miss, false);         % �ҽ����
standFront.miss3 = readData(dir + "1_standFront/2_3_miss/", true, idxRange_miss, false);         % ����ұ�
standFront.miss4 = readData(dir + "1_standFront/2_4_miss/", true, idxRange_miss, false);         % �ҽ��ұ�
% ��ָ��֡��ȡ���������ֵ
standFront_devide = struct();
standFront_devide.bingo1 = devideMotion(standFront.bingo1, windowLen, winMoveStep);
standFront_devide.bingo2 = devideMotion(standFront.bingo2, windowLen, winMoveStep);
standFront_devide.miss1 = devideMotion(standFront.miss1, windowLen, winMoveStep);
standFront_devide.miss2 = devideMotion(standFront.miss2, windowLen, winMoveStep);
standFront_devide.miss3 = devideMotion(standFront.miss3, windowLen, winMoveStep);
standFront_devide.miss4 = devideMotion(standFront.miss4, windowLen, winMoveStep);
clear standFront;
% ��ֱ���ϲ������NaN
standFront_merge.leftFoot = structMerge(standFront_devide.bingo1, true);
standFront_merge.rightFoot = structMerge(standFront_devide.bingo2, true);
standFront_merge.miss = structMerge([standFront_devide.miss1; standFront_devide.miss2; standFront_devide.miss3; standFront_devide.miss4], true);
standFront_merge.gnd = structMerge([standFront_merge.miss; standFront_merge.rightFoot; standFront_merge.leftFoot], false);
% DBSCAN ����
standFront_dbscan = struct();
standFront_dbscan.leftFoot = structDBSCAN(standFront_merge.leftFoot, epsilon, minPts, 1);
standFront_dbscan.rightFoot = structDBSCAN(standFront_merge.rightFoot, epsilon, minPts, 1);
standFront_dbscan.miss = structDBSCAN(standFront_merge.miss, epsilon, minPts, 2);
% kmeans ���� �����ĵ�
standFront_kmeans = struct();
standFront_kmeans.leftFoot = structKmeans(standFront_dbscan.leftFoot, 1);
standFront_kmeans.rightFoot = structKmeans(standFront_dbscan.rightFoot, 1);
standFront_kmeans.miss = structKmeans(standFront_dbscan.miss, 2);
standFront_kmeans.merge = structMerge([standFront_kmeans.miss; standFront_kmeans.rightFoot; standFront_kmeans.leftFoot], false);
% ��ͼ
% figNum = figNum + 1; figure(figNum); 
% subplot(1,2,1); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(standFront_merge.leftFoot.x, standFront_merge.leftFoot.y, standFront_merge.leftFoot.z, 'filled', 'red', 'DisplayName', '��Ų���');
% scatter3(standFront_merge.rightFoot.x, standFront_merge.rightFoot.y, standFront_merge.rightFoot.z, 'filled', 'magenta', 'DisplayName', '�ҽŲ���');
% scatter3(standFront_merge.miss.x, standFront_merge.miss.y, standFront_merge.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(standFront_merge.gnd.gnd(:,1), standFront_merge.gnd.gnd(:,2), standFront_merge.gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
% legend; title("վ��ǰ��");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;
% subplot(1,2,2); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(standFront_dbscan.leftFoot.x, standFront_dbscan.leftFoot.y, standFront_dbscan.leftFoot.z, 'filled', 'red', 'DisplayName', '��Ų���');
% scatter3(standFront_dbscan.rightFoot.x, standFront_dbscan.rightFoot.y, standFront_dbscan.rightFoot.z, 'filled', 'magenta', 'DisplayName', '�ҽŲ���');
% scatter3(standFront_dbscan.miss.x, standFront_dbscan.miss.y, standFront_dbscan.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(standFront_merge.leftFoot.gnd(:,1), standFront_merge.leftFoot.gnd(:,2), standFront_merge.leftFoot.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
% scatter3(standFront_kmeans.merge.x, standFront_kmeans.merge.y, standFront_kmeans.merge.z, 100, 'MarkerEdgeColor','k', 'MarkerFaceColor', 'yellow', 'DisplayName', '���ĵ�');
% legend; title("վ��ǰ��-DBSCAN����");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;


%% վ�����
standLeft = struct();
standLeft.bingo1 = readData(dir + "2_standLeft/1_1_bingo/", true, idxRange_bingo, false);      % ���
standLeft.bingo2 = readData(dir + "2_standLeft/1_2_bingo/", true, idxRange_bingo, false);      % �ҽ�
standLeft.miss1 = readData(dir + "2_standLeft/2_1_miss/", true, idxRange_miss, false);         % ������
standLeft.miss2 = readData(dir + "2_standLeft/2_2_miss/", true, idxRange_miss + 1, false);     % �ҽ����
% ��ָ��֡��ȡ���������ֵ
standLeft_devide = struct();
standLeft_devide.bingo1 = devideMotion(standLeft.bingo1, windowLen, winMoveStep);
standLeft_devide.bingo2 = devideMotion(standLeft.bingo2, windowLen, winMoveStep);
standLeft_devide.miss1 = devideMotion(standLeft.miss1, windowLen, winMoveStep);
standLeft_devide.miss2 = devideMotion(standLeft.miss2, windowLen, winMoveStep);
clear standLeft;
% ��ֱ���ϲ������NaN
standLeft_merge.leftFoot = structMerge(standLeft_devide.bingo1, true);
standLeft_merge.rightFoot = structMerge(standLeft_devide.bingo2, true);
standLeft_merge.miss = structMerge([standLeft_devide.miss1; standLeft_devide.miss2], true);
standLeft_merge.gnd = structMerge([standLeft_merge.miss; standLeft_merge.rightFoot; standLeft_merge.leftFoot], false);
% DBSCAN ����
standLeft_dbscan = struct();
standLeft_dbscan.leftFoot = structDBSCAN(standLeft_merge.leftFoot, epsilon, minPts, 1);
standLeft_dbscan.rightFoot = structDBSCAN(standLeft_merge.rightFoot, epsilon, minPts, 1);
standLeft_dbscan.miss = structDBSCAN(standLeft_merge.miss, epsilon, minPts, 1);
% kmeans ���� ������
standLeft_kmeans = struct();
standLeft_kmeans.leftFoot = structKmeans(standLeft_dbscan.leftFoot, 1);
standLeft_kmeans.rightFoot = structKmeans(standLeft_dbscan.rightFoot, 1);
standLeft_kmeans.miss = structKmeans(standLeft_dbscan.miss, 2);
standLeft_kmeans.merge = structMerge([standLeft_kmeans.miss; standLeft_kmeans.rightFoot; standLeft_kmeans.leftFoot], false);
% ��ͼ
% figNum = figNum + 1; figure(figNum); 
% subplot(1,2,1); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(standLeft_merge.leftFoot.x, standLeft_merge.leftFoot.y, standLeft_merge.leftFoot.z, 'filled', 'cyan', 'DisplayName', '��Ų���');
% scatter3(standLeft_merge.rightFoot.x, standLeft_merge.rightFoot.y ,standLeft_merge.rightFoot.z, 'filled', 'blue', 'DisplayName', '�ҽŲ���');
% scatter3(standLeft_merge.miss.x, standLeft_merge.miss.y, standLeft_merge.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(standLeft_merge.leftFoot.gnd(:,1), standLeft_merge.leftFoot.gnd(:,2), standLeft_merge.leftFoot.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
% legend; title("վ�����");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;
% subplot(1,2,2); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(standLeft_dbscan.leftFoot.x, standLeft_dbscan.leftFoot.y, standLeft_dbscan.leftFoot.z, 'filled', 'cyan', 'DisplayName', '��Ų���');
% scatter3(standLeft_dbscan.rightFoot.x, standLeft_dbscan.rightFoot.y ,standLeft_dbscan.rightFoot.z, 'filled', 'blue', 'DisplayName', '�ҽŲ���');
% scatter3(standLeft_dbscan.miss.x, standLeft_dbscan.miss.y, standLeft_dbscan.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(standLeft_merge.gnd.gnd(:,1), standLeft_merge.gnd.gnd(:,2), standLeft_merge.gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
% scatter3(standLeft_kmeans.merge.x, standLeft_kmeans.merge.y, standLeft_kmeans.merge.z, 100, 'MarkerEdgeColor','k', 'MarkerFaceColor', 'yellow', 'DisplayName', '���ĵ�');
% legend; title("վ�����-DBSCAN����");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;


%% վ���ұ�
standRight = struct();
standRight.bingo1 = readData(dir + "3_standRight/1_1_bingo/", true, idxRange_bingo, false);      % ���
standRight.bingo2 = readData(dir + "3_standRight/1_2_bingo/", true, idxRange_bingo, false);      % �ҽ�
standRight.miss1 = readData(dir + "3_standRight/2_1_miss/", true, idxRange_miss, false);         % ������
standRight.miss2 = readData(dir + "3_standRight/2_2_miss/", true, idxRange_miss, false);         % �ҽ����
% ��ָ��֡��ȡ���������ֵ
standRight_devide = struct();
standRight_devide.bingo1 = devideMotion(standRight.bingo1, windowLen, winMoveStep);
standRight_devide.bingo2 = devideMotion(standRight.bingo2, windowLen, winMoveStep);
standRight_devide.miss1 = devideMotion(standRight.miss1, windowLen, winMoveStep);
standRight_devide.miss2 = devideMotion(standRight.miss2, windowLen, winMoveStep);
clear standRight;
% ��ֱ���ϲ������NaN
standRight_merge.leftFoot = structMerge(standRight_devide.bingo1, true);
standRight_merge.rightFoot = structMerge(standRight_devide.bingo2, true);
standRight_merge.miss = structMerge([standRight_devide.miss1; standRight_devide.miss2], true);
standRight_merge.gnd = structMerge([standRight_merge.miss; standRight_merge.rightFoot; standRight_merge.leftFoot], false);
% DBSCAN ����
standRight_dbscan = struct();
standRight_dbscan.leftFoot = structDBSCAN(standRight_merge.leftFoot, epsilon, minPts, 1);
standRight_dbscan.rightFoot = structDBSCAN(standRight_merge.rightFoot, epsilon, minPts, 1);
standRight_dbscan.miss = structDBSCAN(standRight_merge.miss, epsilon, minPts, 1);
% kmeans ���� ������
standRight_kmeans = struct();
standRight_kmeans.leftFoot = structKmeans(standRight_dbscan.leftFoot, 1);
standRight_kmeans.rightFoot = structKmeans(standRight_dbscan.rightFoot, 1);
standRight_kmeans.miss = structKmeans(standRight_dbscan.miss, 2);
standRight_kmeans.merge = structMerge([standRight_kmeans.miss; standRight_kmeans.rightFoot; standRight_kmeans.leftFoot], false);
% ��ͼ
% figNum = figNum + 1; figure(figNum); 
% subplot(1,2,1); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(standRight_merge.leftFoot.x, standRight_merge.leftFoot.y, standRight_merge.leftFoot.z, 'filled', 'cyan', 'DisplayName', '��Ų���');
% scatter3(standRight_merge.rightFoot.x, standRight_merge.rightFoot.y, standRight_merge.rightFoot.z, 'filled', 'blue', 'DisplayName', '�ҽŲ���');
% scatter3(standRight_merge.miss.x, standRight_merge.miss.y, standRight_merge.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(standRight_merge.gnd.gnd(:,1), standRight_merge.gnd.gnd(:,2), standRight_merge.gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
% legend; title("վ���ұ�");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;
% subplot(1,2,2); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(standRight_dbscan.leftFoot.x, standRight_dbscan.leftFoot.y, standRight_dbscan.leftFoot.z, 'filled', 'cyan', 'DisplayName', '��Ų���');
% scatter3(standRight_dbscan.rightFoot.x, standRight_dbscan.rightFoot.y, standRight_dbscan.rightFoot.z, 'filled', 'blue', 'DisplayName', '�ҽŲ���');
% scatter3(standRight_dbscan.miss.x, standRight_dbscan.miss.y, standRight_dbscan.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(standRight_merge.gnd.gnd(:,1), standRight_merge.gnd.gnd(:,2), standRight_merge.gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
% scatter3(standRight_kmeans.merge.x, standRight_kmeans.merge.y, standRight_kmeans.merge.z, 100, 'MarkerEdgeColor','k', 'MarkerFaceColor', 'yellow', 'DisplayName', '���ĵ�');
% legend; title("վ���ұ�-DBSCAN����");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;


%% ���ƻ���ͼ
% ��ֱ���ϲ�
generalPic.standLeft = structMerge([standLeft_merge.rightFoot, standLeft_merge.leftFoot], false);
generalPic.standRight = structMerge([standRight_merge.rightFoot, standRight_merge.leftFoot], false);
generalPic.standFront = structMerge([standFront_merge.rightFoot, standFront_merge.leftFoot], false);
generalPic.miss = structMerge([standLeft_merge.miss; standRight_merge.miss; standFront_merge.miss], false);
generalPic.gnd = structMerge([generalPic.miss; generalPic.standLeft; generalPic.standRight; generalPic.standFront], false);
% DBSCAN ����
generalPic_dbscan = struct();
generalPic_dbscan.standLeft = structDBSCAN(generalPic.standLeft, epsilon, minPts, 2);
generalPic_dbscan.standRight = structDBSCAN(generalPic.standRight, epsilon, minPts, 2);
generalPic_dbscan.standFront = structDBSCAN(generalPic.standFront, epsilon, minPts, 1);
% generalPic_dbscan.miss = structDBSCAN(generalPic.miss, epsilon, minPts, 1);
% kmeans ����
generalPic_kmeans = struct();
generalPic_kmeans.standLeft = structKmeans(generalPic_dbscan.standLeft, 2);
generalPic_kmeans.standRight = structKmeans(generalPic_dbscan.standRight, 2);
generalPic_kmeans.standFront = structKmeans(generalPic_dbscan.standFront, 1);
generalPic_kmeans.merge = structMerge([generalPic_kmeans.standLeft; generalPic_kmeans.standRight; generalPic_kmeans.standFront], false);
% ��ͼ
figNum = figNum + 1; figure(figNum); 
subplot(1,2,1); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(generalPic.miss.x, generalPic.miss.y, generalPic.miss.z, 'black', 'DisplayName', 'û����');
scatter3(generalPic.standLeft.x, generalPic.standLeft.y ,generalPic.standLeft.z, 'filled', 'blue', 'DisplayName', 'Stand left');
scatter3(generalPic.standRight.x, generalPic.standRight.y, generalPic.standRight.z, 'filled', 'cyan', 'DisplayName', 'Stand right');
scatter3(generalPic.standFront.x, generalPic.standFront.y, generalPic.standFront.z, 'filled', 'red', 'DisplayName', 'Stand front');
% scatter3(generalPic.gnd.gnd(:,1), generalPic.gnd.gnd(:,2), generalPic.gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
set(gca, 'FontSize', 26);
legend; title("����ͼ����");
xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
view(0, 85); grid('on');
hold off;
subplot(1,2,2); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(generalPic_dbscan.miss.x, generalPic_dbscan.miss.y, generalPic_dbscan.miss.z, 'black', 'DisplayName', 'û����');
scatter3(generalPic_dbscan.standLeft.x, generalPic_dbscan.standLeft.y ,generalPic_dbscan.standLeft.z, 'filled', 'blue', 'DisplayName', 'Stand left');
scatter3(generalPic_dbscan.standRight.x, generalPic_dbscan.standRight.y, generalPic_dbscan.standRight.z, 'filled', 'cyan', 'DisplayName', 'Stand right');
scatter3(generalPic_dbscan.standFront.x, generalPic_dbscan.standFront.y, generalPic_dbscan.standFront.z, 'filled', 'red', 'DisplayName', 'Stand front');
% scatter3(generalPic.gnd.gnd(:,1), generalPic.gnd.gnd(:,2), generalPic.gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
scatter3(generalPic_kmeans.merge.x, generalPic_kmeans.merge.y, generalPic_kmeans.merge.z, 100, 'MarkerEdgeColor','k', 'MarkerFaceColor', 'yellow', 'DisplayName', '���ĵ�');
set(gca, 'FontSize', 26);
legend; title("����ͼ����-DBSCAN����");
xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
view(0, 85); grid('on');
hold off;


%% �ָ�ģ���̤����������������
% groupNum = floor(1 / winMoveStep);   
% groupNum = floor(2 * 30 / winMoveStep);   % ÿ2����һ�ξ��࣬�þ����2����Ҫ������
groupNum = floor(30 / winMoveStep);   % ÿ1����һ�ξ��࣬�þ����1����Ҫ������
kmeansDot = struct();
kmeansDot.front = []; kmeansDot.left = []; kmeansDot.right = []; kmeansDot.miss = [];
% bingo
for j = 0 : floor(size(standFront_devide.bingo1.x, 1) / groupNum) - 1     
    idxStart = 1 + groupNum * j;        % ��ʼ֡����
    idxEnd = idxStart + groupNum - 1;   % ����֡����
    
    %% վ��ǰ��
    tmp_standFront = struct();
    tmp_standFront.bingo1 = structIntercept(standFront_devide.bingo1, idxStart, idxEnd);
    tmp_standFront.bingo2 = structIntercept(standFront_devide.bingo2, idxStart, idxEnd);
    % ��ֱ���ϲ������NaN
    tmp_standFront_merge.leftFoot = structMerge(tmp_standFront.bingo1, true);
    tmp_standFront_merge.rightFoot = structMerge(tmp_standFront.bingo2, true);
    % DBSCAN ����
    tmp_standFront_dbscan = struct();
    tmp_standFront_dbscan.leftFoot = structDBSCAN(tmp_standFront_merge.leftFoot, epsilon, minPts, 1);
    tmp_standFront_dbscan.rightFoot = structDBSCAN(tmp_standFront_merge.rightFoot, epsilon, minPts, 1);
    % kmeans ����
    tmp_standFront_kmeans = struct();
    tmp_standFront_kmeans.leftFoot = structKmeans(tmp_standFront_dbscan.leftFoot, 1);
    tmp_standFront_kmeans.rightFoot = structKmeans(tmp_standFront_dbscan.rightFoot, 1);
    tmp_standFront_kmeans.merge = structMerge([tmp_standFront_kmeans.rightFoot; tmp_standFront_kmeans.leftFoot], false);
    
    %% վ�����
    tmp_standLeft = struct();
    tmp_standLeft.bingo1 = structIntercept(standLeft_devide.bingo1, idxStart, idxEnd);
    tmp_standLeft.bingo2 = structIntercept(standLeft_devide.bingo2, idxStart, idxEnd);
    % ��ֱ���ϲ������NaN
    tmp_standLeft_merge.leftFoot = structMerge(tmp_standLeft.bingo1, true);
    tmp_standLeft_merge.rightFoot = structMerge(tmp_standLeft.bingo2, true);
    % DBSCAN ����
    tmp_standLeft_dbscan = struct();
    tmp_standLeft_dbscan.leftFoot = structDBSCAN(tmp_standLeft_merge.leftFoot, epsilon, minPts, 1);
    tmp_standLeft_dbscan.rightFoot = structDBSCAN(tmp_standLeft_merge.rightFoot, epsilon, minPts, 1);
    % kmeans ����
    tmp_standLeft_kmeans = struct();
    tmp_standLeft_kmeans.leftFoot = structKmeans(tmp_standLeft_dbscan.leftFoot, 1);
    tmp_standLeft_kmeans.rightFoot = structKmeans(tmp_standLeft_dbscan.rightFoot, 1);
    tmp_standLeft_kmeans.merge = structMerge([tmp_standLeft_kmeans.rightFoot; tmp_standLeft_kmeans.leftFoot], false);
    
    %% վ���ұ�
    tmp_standRight = struct();
    tmp_standRight.bingo1 = structIntercept(standRight_devide.bingo1, idxStart, idxEnd);
    tmp_standRight.bingo2 = structIntercept(standRight_devide.bingo2, idxStart, idxEnd);
    % ��ֱ���ϲ������NaN
    tmp_standRight_merge.leftFoot = structMerge(tmp_standRight.bingo2, true);
    tmp_standRight_merge.rightFoot = structMerge(tmp_standRight.bingo1, true);
    % DBSCAN ����
    tmp_standRight_dbscan = struct();
    tmp_standRight_dbscan.leftFoot = structDBSCAN(tmp_standRight_merge.leftFoot, epsilon, minPts, 1);
    tmp_standRight_dbscan.rightFoot = structDBSCAN(tmp_standRight_merge.rightFoot, epsilon, minPts, 1);
    % kmeans ����
    tmp_standRight_kmeans = struct();
    tmp_standRight_kmeans.leftFoot = structKmeans(tmp_standRight_dbscan.leftFoot, 1);
    tmp_standRight_kmeans.rightFoot = structKmeans(tmp_standRight_dbscan.rightFoot, 1);
    tmp_standRight_kmeans.merge = structMerge([tmp_standRight_kmeans.rightFoot; tmp_standRight_kmeans.leftFoot], false); 

    %% OPTICS
%     clusterDBSCAN.discoverClusters([tmp_standFront_merge.rightFoot.x, tmp_standFront_merge.rightFoot.y, tmp_standFront_merge.rightFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standFront_merge.leftFoot.x, tmp_standFront_merge.leftFoot.y, tmp_standFront_merge.leftFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standLeft_merge.rightFoot.x, tmp_standLeft_merge.rightFoot.y, tmp_standLeft_merge.rightFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standLeft_merge.leftFoot.x, tmp_standLeft_merge.leftFoot.y, tmp_standLeft_merge.leftFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standRight_merge.rightFoot.x, tmp_standRight_merge.rightFoot.y, tmp_standRight_merge.rightFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standRight_merge.leftFoot.x, tmp_standRight_merge.leftFoot.y, tmp_standRight_merge.leftFoot.z], largerEpsilon, minPts);
    
    %% ��ͼ
%     tmp_miss = structMerge([tmp_standFront_merge.miss; tmp_standLeft_merge.miss; tmp_standRight_merge.miss], false);
%     tmp_miss_dbscan = structMerge([tmp_standFront_dbscan.miss; tmp_standLeft_dbscan.miss; tmp_standRight_dbscan.miss], false);
%     tmp_gnd = structMerge([...
%         tmp_standFront_merge.miss; tmp_standFront_merge.rightFoot; tmp_standFront_merge.leftFoot;...
%         tmp_standLeft_merge.miss; tmp_standLeft_merge.rightFoot; tmp_standLeft_merge.leftFoot;...
%         tmp_standRight_merge.miss; tmp_standRight_merge.rightFoot; tmp_standRight_merge.leftFoot;...
%         ],false);
%     tmp_kmeans = structMerge([tmp_standFront_kmeans.merge; tmp_standLeft_kmeans.merge; tmp_standRight_kmeans.merge],false);
%     
%     figNum = figNum + 1; figure(figNum); 
%     subplot(1,2,1); hold on;
%     scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
%     scatter3(tmp_standFront_merge.rightFoot.x, tmp_standFront_merge.rightFoot.y, tmp_standFront_merge.rightFoot.z, 'filled', 'DisplayName', 'վ��ǰ��-�ҽŲ���');
%     scatter3(tmp_standFront_merge.leftFoot.x, tmp_standFront_merge.leftFoot.y, tmp_standFront_merge.leftFoot.z, 'filled', 'DisplayName', 'վ��ǰ��-��Ų���');
%     scatter3(tmp_standLeft_merge.rightFoot.x, tmp_standLeft_merge.rightFoot.y, tmp_standLeft_merge.rightFoot.z, 'filled', 'DisplayName', 'վ�����-�ҽŲ���');
%     scatter3(tmp_standLeft_merge.leftFoot.x, tmp_standLeft_merge.leftFoot.y, tmp_standLeft_merge.leftFoot.z, 'filled', 'DisplayName', 'վ�����-��Ų���');
%     scatter3(tmp_standRight_merge.rightFoot.x, tmp_standRight_merge.rightFoot.y, tmp_standRight_merge.rightFoot.z, 'filled', 'DisplayName', 'վ���ұ�-�ҽŲ���');
%     scatter3(tmp_standRight_merge.leftFoot.x, tmp_standRight_merge.leftFoot.y, tmp_standRight_merge.leftFoot.z, 'filled', 'DisplayName', 'վ���ұ�-��Ų���');
%     scatter3(tmp_gnd.gnd(:,1), tmp_gnd.gnd(:,2), tmp_gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
%     scatter3(tmp_miss.x, tmp_miss.y, tmp_miss.z, 'black', 'DisplayName', 'û����');
%     legend; title("Ƭ��");
%     xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
%     xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
%     view(0, 85); grid('on');
%     hold off;
%     subplot(1,2,2); hold on;
%     scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
%     scatter3(tmp_standFront_dbscan.rightFoot.x, tmp_standFront_dbscan.rightFoot.y, tmp_standFront_dbscan.rightFoot.z, 'filled', 'DisplayName', 'վ��ǰ��-�ҽŲ���');
%     scatter3(tmp_standFront_dbscan.leftFoot.x, tmp_standFront_dbscan.leftFoot.y, tmp_standFront_dbscan.leftFoot.z, 'filled', 'DisplayName', 'վ��ǰ��-��Ų���');
%     scatter3(tmp_standLeft_dbscan.rightFoot.x, tmp_standLeft_dbscan.rightFoot.y, tmp_standLeft_dbscan.rightFoot.z, 'filled', 'DisplayName', 'վ�����-�ҽŲ���');
%     scatter3(tmp_standLeft_dbscan.leftFoot.x, tmp_standLeft_dbscan.leftFoot.y, tmp_standLeft_dbscan.leftFoot.z, 'filled', 'DisplayName', 'վ�����-��Ų���');
%     scatter3(tmp_standRight_dbscan.rightFoot.x, tmp_standRight_dbscan.rightFoot.y, tmp_standRight_dbscan.rightFoot.z, 'filled', 'DisplayName', 'վ���ұ�-�ҽŲ���');
%     scatter3(tmp_standRight_dbscan.leftFoot.x, tmp_standRight_dbscan.leftFoot.y, tmp_standRight_dbscan.leftFoot.z, 'filled', 'DisplayName', 'վ���ұ�-��Ų���');
%     scatter3(tmp_gnd.gnd(:,1), tmp_gnd.gnd(:,2), tmp_gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
%     scatter3(tmp_kmeans.x, tmp_kmeans.y, tmp_kmeans.z, 100, 'MarkerEdgeColor','k', 'MarkerFaceColor', 'yellow', 'DisplayName', '���ĵ�');
%     scatter3(tmp_miss_dbscan.x, tmp_miss_dbscan.y, tmp_miss_dbscan.z, 'black', 'DisplayName', 'û����');
%     legend; title("Ƭ��-DBSCAN����");
%     xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
%     xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
%     view(0, 85); grid('on');
%     hold off;    

    %% ��¼
    kmeansDot.front = structMerge([kmeansDot.front; tmp_standFront_kmeans.rightFoot; tmp_standFront_kmeans.leftFoot], false);
    kmeansDot.left = structMerge([kmeansDot.left; tmp_standLeft_kmeans.rightFoot; tmp_standLeft_kmeans.leftFoot], false);
    kmeansDot.right = structMerge([kmeansDot.right; tmp_standRight_kmeans.rightFoot; tmp_standRight_kmeans.leftFoot], false);
end

for j = 0 : floor(size(standFront_devide.miss1.x, 1) / groupNum) - 1     
    idxStart = 1 + groupNum * j;        % ��ʼ֡����
    idxEnd = idxStart + groupNum - 1;   % ����֡����
    
    %% վ��ǰ��
    tmp_standFront = struct();
    tmp_standFront.miss1 = structIntercept(standFront_devide.miss1, idxStart, idxEnd);
    tmp_standFront.miss2 = structIntercept(standFront_devide.miss2, idxStart, idxEnd);
    tmp_standFront.miss3 = structIntercept(standFront_devide.miss3, idxStart, idxEnd);
    tmp_standFront.miss4 = structIntercept(standFront_devide.miss4, idxStart, idxEnd);
    % ��ֱ���ϲ������NaN
    tmp_standFront_merge.miss = structMerge([tmp_standFront.miss1; tmp_standFront.miss2; tmp_standFront.miss3; tmp_standFront.miss4], true);
    % DBSCAN ����
    tmp_standFront_dbscan = struct();
    tmp_standFront_dbscan.miss = structDBSCAN(tmp_standFront_merge.miss, epsilon, minPts, 2);
    % kmeans ����
    tmp_standFront_kmeans = struct();
    tmp_standFront_kmeans.miss = structKmeans(tmp_standFront_dbscan.miss, 2);
    
    %% վ�����
    tmp_standLeft = struct();
    tmp_standLeft.miss1 = structIntercept(standLeft_devide.miss1, idxStart, idxEnd);
    tmp_standLeft.miss2 = structIntercept(standLeft_devide.miss2, idxStart, idxEnd);
    % ��ֱ���ϲ������NaN
    tmp_standLeft_merge.miss = structMerge([tmp_standLeft.miss1; tmp_standLeft.miss2], true);
    % DBSCAN ����
    tmp_standLeft_dbscan = struct();
    tmp_standLeft_dbscan.miss = structDBSCAN(tmp_standLeft_merge.miss, epsilon, minPts, 1);
    % kmeans ����
    tmp_standLeft_kmeans = struct();
    tmp_standLeft_kmeans.miss = structKmeans(tmp_standLeft_dbscan.miss, 1);
    
    %% վ���ұ�
    tmp_standRight = struct();
    tmp_standRight.miss1 = structIntercept(standRight_devide.miss1, idxStart, idxEnd);
    tmp_standRight.miss2 = structIntercept(standRight_devide.miss2, idxStart, idxEnd);
    % ��ֱ���ϲ������NaN
    tmp_standRight_merge.miss = structMerge([tmp_standRight.miss1; tmp_standRight.miss2], true);
    % DBSCAN ����
    tmp_standRight_dbscan = struct();
    tmp_standRight_dbscan.miss = structDBSCAN(tmp_standRight_merge.miss, epsilon, minPts, 1);
    % kmeans ����
    tmp_standRight_kmeans = struct();
    tmp_standRight_kmeans.miss = structKmeans(tmp_standRight_dbscan.miss, 1);

    %% OPTICS
%     clusterDBSCAN.discoverClusters([tmp_standFront_merge.rightFoot.x, tmp_standFront_merge.rightFoot.y, tmp_standFront_merge.rightFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standFront_merge.leftFoot.x, tmp_standFront_merge.leftFoot.y, tmp_standFront_merge.leftFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standLeft_merge.rightFoot.x, tmp_standLeft_merge.rightFoot.y, tmp_standLeft_merge.rightFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standLeft_merge.leftFoot.x, tmp_standLeft_merge.leftFoot.y, tmp_standLeft_merge.leftFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standRight_merge.rightFoot.x, tmp_standRight_merge.rightFoot.y, tmp_standRight_merge.rightFoot.z], largerEpsilon, minPts);
%     clusterDBSCAN.discoverClusters([tmp_standRight_merge.leftFoot.x, tmp_standRight_merge.leftFoot.y, tmp_standRight_merge.leftFoot.z], largerEpsilon, minPts);
    
    %% ��ͼ
%     tmp_miss = structMerge([tmp_standFront_merge.miss; tmp_standLeft_merge.miss; tmp_standRight_merge.miss], false);
%     tmp_miss_dbscan = structMerge([tmp_standFront_dbscan.miss; tmp_standLeft_dbscan.miss; tmp_standRight_dbscan.miss], false);
%     tmp_gnd = structMerge([...
%         tmp_standFront_merge.miss; tmp_standFront_merge.rightFoot; tmp_standFront_merge.leftFoot;...
%         tmp_standLeft_merge.miss; tmp_standLeft_merge.rightFoot; tmp_standLeft_merge.leftFoot;...
%         tmp_standRight_merge.miss; tmp_standRight_merge.rightFoot; tmp_standRight_merge.leftFoot;...
%         ],false);
%     tmp_kmeans = structMerge([tmp_standFront_kmeans.merge; tmp_standLeft_kmeans.merge; tmp_standRight_kmeans.merge],false);
%     
%     figNum = figNum + 1; figure(figNum); 
%     subplot(1,2,1); hold on;
%     scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
%     scatter3(tmp_standFront_merge.rightFoot.x, tmp_standFront_merge.rightFoot.y, tmp_standFront_merge.rightFoot.z, 'filled', 'DisplayName', 'վ��ǰ��-�ҽŲ���');
%     scatter3(tmp_standFront_merge.leftFoot.x, tmp_standFront_merge.leftFoot.y, tmp_standFront_merge.leftFoot.z, 'filled', 'DisplayName', 'վ��ǰ��-��Ų���');
%     scatter3(tmp_standLeft_merge.rightFoot.x, tmp_standLeft_merge.rightFoot.y, tmp_standLeft_merge.rightFoot.z, 'filled', 'DisplayName', 'վ�����-�ҽŲ���');
%     scatter3(tmp_standLeft_merge.leftFoot.x, tmp_standLeft_merge.leftFoot.y, tmp_standLeft_merge.leftFoot.z, 'filled', 'DisplayName', 'վ�����-��Ų���');
%     scatter3(tmp_standRight_merge.rightFoot.x, tmp_standRight_merge.rightFoot.y, tmp_standRight_merge.rightFoot.z, 'filled', 'DisplayName', 'վ���ұ�-�ҽŲ���');
%     scatter3(tmp_standRight_merge.leftFoot.x, tmp_standRight_merge.leftFoot.y, tmp_standRight_merge.leftFoot.z, 'filled', 'DisplayName', 'վ���ұ�-��Ų���');
%     scatter3(tmp_gnd.gnd(:,1), tmp_gnd.gnd(:,2), tmp_gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
%     scatter3(tmp_miss.x, tmp_miss.y, tmp_miss.z, 'black', 'DisplayName', 'û����');
%     legend; title("Ƭ��");
%     xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
%     xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
%     view(0, 85); grid('on');
%     hold off;
%     subplot(1,2,2); hold on;
%     scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
%     scatter3(tmp_standFront_dbscan.rightFoot.x, tmp_standFront_dbscan.rightFoot.y, tmp_standFront_dbscan.rightFoot.z, 'filled', 'DisplayName', 'վ��ǰ��-�ҽŲ���');
%     scatter3(tmp_standFront_dbscan.leftFoot.x, tmp_standFront_dbscan.leftFoot.y, tmp_standFront_dbscan.leftFoot.z, 'filled', 'DisplayName', 'վ��ǰ��-��Ų���');
%     scatter3(tmp_standLeft_dbscan.rightFoot.x, tmp_standLeft_dbscan.rightFoot.y, tmp_standLeft_dbscan.rightFoot.z, 'filled', 'DisplayName', 'վ�����-�ҽŲ���');
%     scatter3(tmp_standLeft_dbscan.leftFoot.x, tmp_standLeft_dbscan.leftFoot.y, tmp_standLeft_dbscan.leftFoot.z, 'filled', 'DisplayName', 'վ�����-��Ų���');
%     scatter3(tmp_standRight_dbscan.rightFoot.x, tmp_standRight_dbscan.rightFoot.y, tmp_standRight_dbscan.rightFoot.z, 'filled', 'DisplayName', 'վ���ұ�-�ҽŲ���');
%     scatter3(tmp_standRight_dbscan.leftFoot.x, tmp_standRight_dbscan.leftFoot.y, tmp_standRight_dbscan.leftFoot.z, 'filled', 'DisplayName', 'վ���ұ�-��Ų���');
%     scatter3(tmp_gnd.gnd(:,1), tmp_gnd.gnd(:,2), tmp_gnd.gnd(:,3), 'filled', 'green', 'DisplayName', '����');
%     scatter3(tmp_kmeans.x, tmp_kmeans.y, tmp_kmeans.z, 100, 'MarkerEdgeColor','k', 'MarkerFaceColor', 'yellow', 'DisplayName', '���ĵ�');
%     scatter3(tmp_miss_dbscan.x, tmp_miss_dbscan.y, tmp_miss_dbscan.z, 'black', 'DisplayName', 'û����');
%     legend; title("Ƭ��-DBSCAN����");
%     xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
%     xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
%     view(0, 85); grid('on');
%     hold off;    

    %% ��¼
    kmeansDot.miss = structMerge([kmeansDot.miss; tmp_standFront_kmeans.miss; tmp_standLeft_kmeans.miss; tmp_standRight_kmeans.miss], false);
end
clear j idxStart idxEnd;
clear tmp_standFront tmp_standFront_dbscan tmp_standFront_kmeans tmp_standFront_kmeans tmp_standFront_merge;
clear tmp_standLeft tmp_standLeft_dbscan tmp_standLeft_kmeans tmp_standLeft_kmeans tmp_standLeft_merge;
clear tmp_standRight tmp_standRight_dbscan tmp_standRight_kmeans tmp_standRight_kmeans tmp_standRight_merge;

%% ���ĵ�
% clusterDBSCAN.discoverClusters([kmeansDot.front.x, kmeansDot.front.y, kmeansDot.front.z], largerEpsilon, minPts);
% clusterDBSCAN.discoverClusters([kmeansDot.left.x, kmeansDot.left.y, kmeansDot.left.z], largerEpsilon, minPts);
% clusterDBSCAN.discoverClusters([kmeansDot.right.x, kmeansDot.right.y, kmeansDot.right.z], largerEpsilon, minPts);
% clusterDBSCAN.discoverClusters([kmeansDot.miss.x, kmeansDot.miss.y, kmeansDot.miss.z], largerEpsilon, minPts);
kmeansDot_dbscan  = struct();
kmeansDot_dbscan.front = structDBSCAN(kmeansDot.front, 0.03, minPts, 1);
kmeansDot_dbscan.left = structDBSCAN(kmeansDot.left, 0.04, minPts, 1);
kmeansDot_dbscan.right = structDBSCAN(kmeansDot.right, 0.04, minPts, 1);
kmeansDot_dbscan.miss = structDBSCAN(kmeansDot.miss, 0.08, minPts, 4);

figNum = figNum + 1; figure(figNum); 
subplot(1,2,1); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(kmeansDot.miss.x, kmeansDot.miss.y, kmeansDot.miss.z, 'black', 'DisplayName', 'û����');
scatter3(kmeansDot.front.x, kmeansDot.front.y, kmeansDot.front.z, 'filled', 'red', 'DisplayName', 'Stand front');
scatter3(kmeansDot.left.x, kmeansDot.left.y, kmeansDot.left.z, 'filled', 'blue', 'DisplayName', 'Stand left');
scatter3(kmeansDot.right.x, kmeansDot.right.y, kmeansDot.right.z, 'filled', 'cyan', 'DisplayName', 'Stand right');
set(gca, 'FontSize', 26);
legend; title("���ĵ����");
xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
xlim([-0.6 0.6]);   ylim([0 1.5]);    zlim([-0.8 0.4]); 
view(0, 85); grid('on');
hold off;
subplot(1,2,2); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(kmeansDot_dbscan.miss.x, kmeansDot_dbscan.miss.y, kmeansDot_dbscan.miss.z, 'black', 'DisplayName', 'û����');
scatter3(kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z, 'filled', 'red', 'DisplayName', 'Stand front');
scatter3(kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z, 'filled', 'blue', 'DisplayName', 'Stand left');
scatter3(kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z, 'filled', 'cyan', 'DisplayName', 'Stand right');
set(gca, 'FontSize', 26);
legend; title("���ĵ����-�پ���");
xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
xlim([-0.6 0.6]);   ylim([0 1.5]);    zlim([-0.8 0.4]); 
view(0, 85); grid('on');
hold off;

%% �߽���ȡ
% ͹��-2D
% figNum = figNum + 1; 
% figure(figNum); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% % scatter3(kmeansDot_dbscan.miss.x, kmeansDot_dbscan.miss.y, kmeansDot_dbscan.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z, 'filled', 'red', 'DisplayName', 'վ��ǰ��');
% scatter3(kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z, 'filled', 'blue', 'DisplayName', 'վ�����');
% scatter3(kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z, 'filled', 'cyan', 'DisplayName', 'վ���ұ�');
% [K,~] = convhull(kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z);
% plot3(zeros(length(K),1) + max(kmeansDot_dbscan.front.x), kmeansDot_dbscan.front.y(K),kmeansDot_dbscan.front.z(K), 'black', 'DisplayName', 'վ��ǰ��-�߽�');
% [K,~] = convhull(kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z);
% plot3(zeros(length(K),1) + max(kmeansDot_dbscan.left.x), kmeansDot_dbscan.left.y(K),kmeansDot_dbscan.left.z(K), 'black', 'DisplayName', 'վ�����-�߽�');
% [K,~] = convhull(kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z);
% plot3(zeros(length(K),1) + max(kmeansDot_dbscan.right.x), kmeansDot_dbscan.right.y(K),kmeansDot_dbscan.right.z(K), 'black', 'DisplayName', 'վ���ұ�-�߽�');
% legend; title("���ĵ����-�پ���-�߽���ȡ");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;

% ͹��-3D
% figNum = figNum + 1; figure(figNum); 
% subplot(1,2,1); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(kmeansDot_dbscan.miss.x, kmeansDot_dbscan.miss.y, kmeansDot_dbscan.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z, 'filled', 'red', 'DisplayName', 'վ��ǰ��');
% scatter3(kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z, 'filled', 'blue', 'DisplayName', 'վ�����');
% scatter3(kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z, 'filled', 'cyan', 'DisplayName', 'վ���ұ�');
% legend; title("���ĵ����-�پ���");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;
% subplot(1,2,2); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% [K,~] = convhull(kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z);
% trisurf(K, kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y,kmeansDot_dbscan.front.z, 'Facecolor','red', 'DisplayName', 'վ��ǰ��-�߽�');
% [K,~] = convhull(kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z);
% trisurf(K, kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y,kmeansDot_dbscan.left.z, 'Facecolor','blue', 'DisplayName', 'վ�����-�߽�');
% [K,~] = convhull(kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z);
% trisurf(K, kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y,kmeansDot_dbscan.right.z, 'Facecolor','cyan', 'DisplayName', 'վ���ұ�-�߽�');
% legend; title("���ĵ����-�߽���ȡ");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;

% % alphaShape-3D
% figNum = figNum + 1; figure(figNum); 
% subplot(1,2,1); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(kmeansDot_dbscan.miss.x, kmeansDot_dbscan.miss.y, kmeansDot_dbscan.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z, 'filled', 'red', 'DisplayName', 'վ��ǰ��');
% scatter3(kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z, 'filled', 'blue', 'DisplayName', 'վ�����');
% scatter3(kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z, 'filled', 'cyan', 'DisplayName', 'վ���ұ�');
% legend; title("���ĵ����-�پ���");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;
% subplot(1,2,2); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% shp = alphaShape(kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z, 1);  plot(shp);
% shp = alphaShape(kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z, 1);     plot(shp);
% shp = alphaShape(kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z, 1);  plot(shp);
% title("���ĵ����-�߽���ȡ");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;

% �Ի��߽�-3D
% figNum = figNum + 1; 
% figure(figNum); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
% scatter3(kmeansDot_dbscan.miss.x, kmeansDot_dbscan.miss.y, kmeansDot_dbscan.miss.z, 'black', 'DisplayName', 'û����');
% scatter3(kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z, 'filled', 'red', 'DisplayName', 'վ��ǰ��');
% scatter3(kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z, 'filled', 'blue', 'DisplayName', 'վ�����');
% scatter3(kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z, 'filled', 'cyan', 'DisplayName', 'վ���ұ�');
% % x1 = [0.038, 0.038, 0.038, 0.038, 0.038, 0.038, 0.038, -0.038, -0.038, -0.038, -0.038, -0.038, -0.038, -0.038, -0.038];
% % y1 = [0.6, 0.66, 0.72, 0.72, 0.66, 0.6, 0.6, 0.6, 0.6, 0.66, 0.72, 0.72, 0.66, 0.6, 0.6];
% % z1 = [-0.44, -0.44, -0.35, -0.26, -0.26, -0.35, -0.44, -0.44, -0.44, -0.44, -0.35, -0.26, -0.26, -0.35, -0.44];
% % plot3(x1, y1, z1, 'color', 'black', 'MarkerSize', 100, 'DisplayName', '�߽�1');
% % % fill3(x, y, z, 'r', 'FaceAlpha', 0.5);
% legend; title("���ĵ����-�߽���ȡ");
% xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
% xlim([-1 1]);   ylim([0 1.5]);    zlim([-1 1]); 
% view(0, 85); grid('on');
% hold off;

%% ֱ�����
% ���ɷַ���PCA
lines = struct();                   % ���߲���
t = linspace(-1, 1, 200);          % ������Χ�������ڲ������������˼������Ҫ������

% ǰ�����ڱȽϼ��У�ѡ��ͶӰ�����ĵ������棬ʵ��Ӧ��ʱҲͶӰ���м���
tmp_kmeansDot_dbscan_front = kmeansDot_dbscan.front;
lines.front.points = [kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z];
lines.front.A = mean(lines.front.points);               % �������Ļ�����Ϊֱ��������
[lines.front.coeff, ~, ~] = pca(lines.front.points);	% PCA ����
lines.front.s = lines.front.coeff(:, 1)';               % ��һ���ɷַ���
lines.front.s(1) = 0.0001;                              % ͶӰ
lines.front.plot = (lines.front.A' + lines.front.s' .* t)';         % ����ֱ���ϵĵ㣬ֱ��ͨ���������ĵ㣬* ��ʾ����˷���.* ��ʾ����Ԫ����˵������
lines.front.xMin = min(tmp_kmeansDot_dbscan_front.x);
lines.front.xMax = max(tmp_kmeansDot_dbscan_front.x);
kmeansDot_dbscan.front.x(:) = lines.front.A(1);     % ͶӰ
lines.front.ranges = structPointToLine3(kmeansDot_dbscan.front, lines.front.s, lines.front.A); % ���е㵽ֱ�ߵľ���
lines.front.rangeMax = ceil(max(lines.front.ranges) * 100) / 100;	% ���е㵽ֱ�ߵľ������ֵ������ȥ��
lines.front.points = [kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z];

lines.left.points = [kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z];
lines.left.A = mean(lines.left.points);                 % �������Ļ�����Ϊֱ��������
[lines.left.coeff, ~, ~] = pca(lines.left.points);      % PCA ����
lines.left.s = lines.left.coeff(:, 1)';                 % ��һ���ɷַ���
lines.left.plot = (lines.left.A' + lines.left.s' .* t)';            % ����ֱ���ϵĵ㣬ֱ��ͨ���������ĵ㣬* ��ʾ����˷���.* ��ʾ����Ԫ����˵������
lines.left.xMin = min(kmeansDot_dbscan.left.x);
lines.left.xMax = max(kmeansDot_dbscan.left.x);
lines.left.ranges = structPointToLine3(kmeansDot_dbscan.left, lines.left.s, lines.left.A); % ���е㵽ֱ�ߵľ���
% lines.left.rangeMax = ceil(max(lines.left.ranges) * 100) / 100;     % ���е㵽ֱ�ߵľ������ֵ������ȥ��
lines.left.rangeMax = ceil(prctile(lines.left.ranges, 90) * 100) / 100;     % ���е㵽ֱ�ߵľ���ٷ�λ��������ȥ��

lines.right.points = [kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z];
lines.right.A = mean(lines.right.points);               % �������Ļ�����Ϊֱ��������
[lines.right.coeff, ~, ~] = pca(lines.right.points);	% PCA ����
lines.right.s = lines.right.coeff(:, 1)';                % ��һ���ɷַ���
lines.right.plot = (lines.right.A' + lines.right.s' .* t)';         % ����ֱ���ϵĵ㣬ֱ��ͨ���������ĵ㣬* ��ʾ����˷���.* ��ʾ����Ԫ����˵������
lines.right.xMin = min(kmeansDot_dbscan.right.x);
lines.right.xMax = max(kmeansDot_dbscan.right.x);
lines.right.ranges = structPointToLine3(kmeansDot_dbscan.right, lines.right.s, lines.right.A); % ���е㵽ֱ�ߵľ���
% lines.right.rangeMax = ceil(max(lines.right.ranges) * 100) / 100;         % ���е㵽ֱ�ߵľ������ֵ������ȥ��
lines.right.rangeMax = ceil(prctile(lines.right.ranges, 90) * 100) / 100;	% ���е㵽ֱ�ߵľ���ٷ�λ��������ȥ��

% ����ֱ�ߵı߽�
% lines.front.budryMin = [min(-0.009, 0.026), min(0.631, 0.701), min(-0.463, -0.235)];     % ֱ�߷�Χ��x y z
% lines.front.budryMax = [max(-0.009, 0.026), max(0.631, 0.701), max(-0.463, -0.235)];
% lines.left.budryMin = [min(0.267, 0.050), min(0.462, 0.758), min(-0.380, 0.020)];  
% lines.left.budryMax = [max(0.267, 0.050), max(0.462, 0.758), max(-0.380, 0.020)];
% lines.right.budryMin = [min(-0.191, -0.046), min(0.483, 0.764), min(-0.426, 0.027)];  
% lines.right.budryMax = [max(-0.191, -0.046), max(0.483, 0.764), max(-0.426, 0.027)];  

% lines.front.budryMin = [floor(min(lines.front.points(:,1))*100)/100, floor(min(lines.front.points(:,2))*100)/100, floor(min(lines.front.points(:,3))*100)/100];     % ֱ�߷�Χ��x y z
% lines.front.budryMax = [ceil(max(lines.front.points(:,1))*100)/100, ceil(max(lines.front.points(:,2))*100)/100, ceil(max(lines.front.points(:,3))*100)/100];
% lines.left.budryMin = [floor(min(lines.left.points(:,1))*100)/100, floor(min(lines.left.points(:,2))*100)/100, floor(min(lines.left.points(:,3))*100)/100];
% lines.left.budryMax = [ceil(max(lines.left.points(:,1))*100)/100, ceil(max(lines.left.points(:,2))*100)/100, ceil(max(lines.left.points(:,3))*100)/100];
% lines.right.budryMin = [floor(min(lines.right.points(:,1))*100)/100, floor(min(lines.right.points(:,2))*100)/100, floor(min(lines.right.points(:,3))*100)/100];
% lines.right.budryMax = [ceil(max(lines.right.points(:,1))*100)/100, ceil(max(lines.right.points(:,2))*100)/100, ceil(max(lines.right.points(:,3))*100)/100];

[lines.front.budry, lines.front.budryMin, lines.front.budryMax] = findLineRange(lines.front);
[lines.left.budry, lines.left.budryMin, lines.left.budryMax] = findLineRange(lines.left);
[lines.right.budry, lines.right.budryMin, lines.right.budryMax] = findLineRange(lines.right);
saveLines(lines);
save ('lines.mat', 'lines');

boundary = [lines.front.budry; lines.left.budry; lines.right.budry];
figNum = figNum + 1; 
figure(figNum); hold on;
% scatter3(0, 0, 0, 'filled', 'black', 'DisplayName', '�״�ԭ��');
scatter3(tmp_kmeansDot_dbscan_front.x, tmp_kmeansDot_dbscan_front.y, tmp_kmeansDot_dbscan_front.z, 'filled', 'red', 'DisplayName', 'Stand front');
% scatter3(kmeansDot_dbscan.front.x, kmeansDot_dbscan.front.y, kmeansDot_dbscan.front.z, 'filled', 'red', 'DisplayName', 'վ��ǰ��');
scatter3(kmeansDot_dbscan.left.x, kmeansDot_dbscan.left.y, kmeansDot_dbscan.left.z, 'filled', 'blue', 'DisplayName', 'Stand left');
scatter3(kmeansDot_dbscan.right.x, kmeansDot_dbscan.right.y, kmeansDot_dbscan.right.z, 'filled', 'cyan', 'DisplayName', 'Stand right');
% scatter3(kmeansDot_dbscan.miss.x, kmeansDot_dbscan.miss.y, kmeansDot_dbscan.miss.z, 'black', 'DisplayName', 'û����');
plot3(lines.front.plot(:,1), lines.front.plot(:,2), lines.front.plot(:,3), 'r-', 'LineWidth', 2, 'DisplayName', 'Stand front');
plot3(lines.left.plot(:,1), lines.left.plot(:,2), lines.left.plot(:,3), 'b-', 'LineWidth', 2, 'DisplayName', 'Stand left');
plot3(lines.right.plot(:,1), lines.right.plot(:,2), lines.right.plot(:,3), 'c-', 'LineWidth', 2, 'DisplayName', 'Stand right');
% scatter3(boundary(:,1), boundary(:,2), boundary(:,3), 'filled', 'black', 'DisplayName', '�߽��');
set(gca, 'FontSize', 26);
legend; title("���ĵ������-PCA");
xlabel('X(m)'); ylabel('Y(m)'); zlabel('Z(m)');
xlim([-0.6 0.6]);   ylim([0 1.5]);    zlim([-0.8 0.4]); 
view(0, 85); grid('on');
hold off;










