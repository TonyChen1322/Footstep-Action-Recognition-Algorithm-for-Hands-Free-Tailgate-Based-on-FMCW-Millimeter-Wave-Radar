%  times: Ҫ�õ�������
function outData = structDBSCAN(impData, epsilon, minPts, times)
    if isempty(impData.x)
        outData = [];
        return;
    end
    outData = struct();
    
    outData.gnd = [];
    outData.x = [];
    outData.y = [];
    outData.z = [];
    outData.r = [];
    outData.v = [];
	
%     idx = dbscan([impData.x, impData.y, impData.z], epsilon, minPts); 
    idx = myDBSCAN([impData.x, impData.y, impData.z], epsilon, minPts); 
    
    for i = 1 : times
        idxWant = find(idx == mode(idx));
        
        outData.x = [outData.x; impData.x(idxWant)]; 
        outData.y = [outData.y; impData.y(idxWant)]; 
        outData.z = [outData.z; impData.z(idxWant)];
%         outData.r = [outData.r; impData.z(idxWant)];
%         outData.v = [outData.v; impData.z(idxWant)];
        
        idx(idxWant) = [];
        impData.x(idxWant) = []; 
        impData.y(idxWant) = []; 
        impData.z(idxWant) = [];
%         impData.r(idxWant) = [];
%         impData.v(idxWant) = [];
    end
end


