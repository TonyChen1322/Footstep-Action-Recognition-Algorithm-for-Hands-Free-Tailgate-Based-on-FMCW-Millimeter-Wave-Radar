function outData = nanMean(impData)
    lenRow = size(impData,2);   % ��ȡ����
    lenCol = size(impData,1);   % ��ȡ����
    outData = zeros(1,lenRow);
    for i = 1 : lenRow
        cnt = 0;
        for j = 1 : lenCol
            if ~isnan(impData(j,i))
                outData(1,i) = outData(1,i) + impData(j,i);
                cnt = cnt + 1;
            end
        end
        outData(1,i) = outData(1,i) / cnt;
    end
end