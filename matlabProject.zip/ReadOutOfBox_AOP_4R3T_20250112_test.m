clear; clc; close all;
%% ��ȡʵ������
dir = "E:/2.GraduationItems/04_Trunk/1_mmWaveRader/3_Projects/0_outOfBox_SourceData/20250112_AOP_4R3T_Motion_test/";
load('lines.mat');
groupLen = 30;          % groupLen֡Ϊһ��
figNum = 0;
epsilon = 0.07;    % DBSCAN ����뾶
minPts = 4;         % DBSCAN ��������С����


%% վ��ǰ��
standFront = struct();
standFront.leftFoot = readData(dir + "1_standFront/1_1_bingo/", false);     % ��� 40��
standFront.rightFoot = readData(dir + "1_standFront/1_2_bingo/", false);	% �ҽ� 40��
judge_standFront_leftFoot = struct();
[judge_standFront_leftFoot.status, judge_standFront_leftFoot.witchCluster, judge_standFront_leftFoot.ranges] = structJudgment2(lines, standFront.leftFoot, 30, epsilon, minPts);
judge_standFront_rightFoot = struct();
[judge_standFront_rightFoot.status, judge_standFront_rightFoot.witchCluster, judge_standFront_rightFoot.ranges] = structJudgment2(lines, standFront.rightFoot, 30, epsilon, minPts);

figNum = figNum + 1; figure(figNum); 
subplot(2,1,1); hold on;
plot(1:length(standFront.leftFoot.x), judge_standFront_leftFoot.status, 'b-', 'LineWidth', 1, 'DisplayName', 'Status');
plot(1:length(standFront.leftFoot.x), sum(standFront.leftFoot.v,2, 'omitnan'), 'r-', 'LineWidth', 1, 'DisplayName', 'Speed m/s');
set(gca, 'FontSize', 20);
legend; title("ǰ��-���");
xlim([0, 5000]+10); xlabel('Point cloud/frame'); 
yticks(-3:1:3); ylim([-3.5, 3.5]);
grid('on'); hold off;
subplot(2,1,2); hold on;
plot(1:length(standFront.rightFoot.x), judge_standFront_rightFoot.status, 'b-', 'LineWidth', 1, 'DisplayName', 'Status');
plot(1:length(standFront.rightFoot.x), sum(standFront.rightFoot.v,2, 'omitnan'), 'r-', 'LineWidth', 1, 'DisplayName', 'Speed m/s');
set(gca, 'FontSize', 20);
legend; title("ǰ��-�ҽ�");
xlim([0, 5000]+10); xlabel('Point cloud/frame'); 
yticks(-3:1:3); ylim([-3.5, 3.5]);
grid('on'); hold off;


%% վ�����
standLeft = struct();
standLeft.leftFoot = readData(dir + "2_standLeft/1_1_bingo/", false);       % ��� 40��
standLeft.rightFoot = readData(dir + "2_standLeft/1_2_bingo/", false);      % �ҽ� 40��
judge_standLeft_leftFoot = struct();
[judge_standLeft_leftFoot.status, judge_standLeft_leftFoot.witchCluster, judge_standLeft_leftFoot.ranges] = structJudgment2(lines, standLeft.leftFoot, 30, epsilon, minPts);
judge_standLeft_rightFoot = struct();
[judge_standLeft_rightFoot.status, judge_standLeft_rightFoot.witchCluster, judge_standLeft_rightFoot.ranges] = structJudgment2(lines, standLeft.rightFoot, 30, epsilon, minPts);

figNum = figNum + 1; figure(figNum); 
subplot(2,1,1); hold on;
plot(1:length(standLeft.leftFoot.x), judge_standLeft_leftFoot.status, 'b-', 'LineWidth', 1, 'DisplayName', 'Status');
plot(1:length(standLeft.leftFoot.x), sum(standLeft.leftFoot.v,2, 'omitnan'), 'r-', 'LineWidth', 1, 'DisplayName', 'Speed m/s');
set(gca, 'FontSize', 20);
legend; title("���-���");
xlim([0, 5000]+10); xlabel('Point cloud/frame'); 
yticks(-3:1:3); ylim([-3.5, 3.5]);
grid('on'); hold off;
subplot(2,1,2); hold on;
plot(1:length(standLeft.rightFoot.x), judge_standLeft_rightFoot.status, 'b-', 'LineWidth', 1, 'DisplayName', 'Status');
plot(1:length(standLeft.rightFoot.x), sum(standLeft.rightFoot.v,2, 'omitnan'), 'r-', 'LineWidth', 1, 'DisplayName', 'Speed m/s');
set(gca, 'FontSize', 20);
legend; title("���-�ҽ�");
xlim([0, 5000]+10); xlabel('Point cloud/frame'); 
yticks(-3:1:3); ylim([-3.5, 3.5]);
grid('on'); hold off;



%% վ���ұ�
standRight = struct();
standRight.leftFoot = readData(dir + "3_standRight/1_1_bingo/", false);     % ��� 40��
standRight.rightFoot = readData(dir + "3_standRight/1_2_bingo/", false);	% �ҽ� 40��
judge_standRight_leftFoot = struct();
[judge_standRight_leftFoot.status, judge_standRight_leftFoot.witchCluster, judge_standRight_leftFoot.ranges] = structJudgment2(lines, standRight.leftFoot, 30, epsilon, minPts);
judge_standRight_rightFoot = struct();
[judge_standRight_rightFoot.status, judge_standRight_rightFoot.witchCluster, judge_standRight_rightFoot.ranges] = structJudgment2(lines, standRight.rightFoot, 30, epsilon, minPts);

figNum = figNum + 1; figure(figNum); 
subplot(2,1,1); hold on;
plot(1:length(standRight.leftFoot.x), judge_standRight_leftFoot.status, 'b-', 'LineWidth', 1, 'DisplayName', 'Status');
plot(1:length(standRight.leftFoot.x), sum(standRight.leftFoot.v,2, 'omitnan'), 'r-', 'LineWidth', 1, 'DisplayName', 'Speed m/s');
set(gca, 'FontSize', 20);
legend; title("�ұ�-���");
xlim([0, 5000]+10); xlabel('Point cloud/frame'); 
yticks(-3:1:3); ylim([-3.5, 3.5]);
grid('on'); hold off;
subplot(2,1,2); hold on;
plot(1:length(standRight.rightFoot.x), judge_standRight_rightFoot.status, 'b-', 'LineWidth', 1, 'DisplayName', 'Status');
plot(1:length(standRight.rightFoot.x), sum(standRight.rightFoot.v,2, 'omitnan'), 'r-', 'LineWidth', 1, 'DisplayName', 'Speed m/s');
set(gca, 'FontSize', 20);
legend; title("�ұ�-�ҽ�");
xlim([0, 5000]+10); xlabel('Point cloud/frame'); 
yticks(-3:1:3); ylim([-3.5, 3.5]);
grid('on'); hold off;



%% δ����
miss = readData(dir + "4_miss/", false);     % 80��
judge_miss = struct();
[judge_miss.status, judge_miss.witchCluster, judge_miss.ranges] = structJudgment2(lines, miss, 30, epsilon, minPts);

figNum = figNum + 1; figure(figNum); 
subplot(2,1,1); hold on;
plot(1:length(miss.x), judge_miss.status, 'b-', 'LineWidth', 1, 'DisplayName', 'Status');
plot(1:length(miss.x), sum(miss.v,2, 'omitnan'), 'r-', 'LineWidth', 1, 'DisplayName', 'Speed m/s');
set(gca, 'FontSize', 20);
legend; title("δ����");
xlim([0, 5000]+10); xlabel('Point cloud/frame'); 
yticks(-3:1:3); ylim([-3.5, 3.5]);
grid('on'); hold off;
subplot(2,1,2); hold on;
set(gca, 'FontSize', 20);
legend; title("δ����");
xlim([0, 5000]+10); xlabel('Point cloud/frame'); 
yticks(-3:1:3); ylim([-3.5, 3.5]);
grid('on'); hold off;


%% �ҳ������׶��ж������ĸ��ص�����
% r11 = sum(standFront.leftFoot.x,2, 'omitnan');  r12 = sum(standFront.rightFoot.x,2, 'omitnan'); r1 = [r11; r12];
% r21 = sum(standLeft.leftFoot.x,2, 'omitnan');   r22 = sum(standLeft.rightFoot.x,2, 'omitnan');  r2 = [r21; r22];
% r31 = sum(standRight.leftFoot.x,2, 'omitnan');  r32 = sum(standRight.rightFoot.x,2, 'omitnan'); r3 = [r31; r32];
% clear r11 r12 r21 r22 r31 r32;
% v11 = sum(standFront.leftFoot.v,2, 'omitnan');  v12 = sum(standFront.rightFoot.v,2, 'omitnan'); v1 = [v11; v12];
% v21 = sum(standLeft.leftFoot.v,2, 'omitnan');   v22 = sum(standLeft.rightFoot.v,2, 'omitnan');  v2 = [v21; v22];
% v31 = sum(standRight.leftFoot.v,2, 'omitnan');  v32 = sum(standRight.rightFoot.v,2, 'omitnan'); v3 = [v31; v32];
% clear v11 v12 v21 v22 v31 v32;
% r1(v1>=0) = []; r2(v2>=0) = []; r3(v3>=0) = [];
% endNum = 1300;
% draw = [r1(1:endNum,:), r2(1:endNum,:), r3(1:endNum,:)];
% clusterLine = mean(draw);
% % save ('clusterLine.mat', 'clusterLine');
% aa = (lines.front.xMax + lines.front.xMin);
% bb = lines.left.xMax * 1.5;
% cc = lines.right.xMin * 1.5;
% xPlot = 1:endNum;
% figNum = figNum + 1;
% figure(figNum); hold on;
% plot(xPlot, r1(1:endNum), 'r-');
% plot(xPlot, r2(1:endNum), 'b-');
% plot(xPlot, r3(1:endNum), 'c-');
% plot(linspace(1, endNum, 2), zeros(2) + clusterLine(1), 'r-', 'LineWidth', 2);
% plot(linspace(1, endNum, 2), zeros(2) + clusterLine(2), 'b-', 'LineWidth', 2);
% plot(linspace(1, endNum, 2), zeros(2) + clusterLine(3), 'c-', 'LineWidth', 2);
% plot(linspace(1, endNum, 2), zeros(2) + aa, 'black', 'LineWidth', 2);
% plot(linspace(1, endNum, 2), zeros(2) + bb, 'black', 'LineWidth', 2);
% plot(linspace(1, endNum, 2), zeros(2) + cc, 'black', 'LineWidth', 2);
% grid('on'); hold off;















